- ReadSMC
(U)EFI shell tool to read SMC keys and signature from real SMC device.