//********************************************************************
//	created:	4:8:2012   17:54
//	filename: 	AppleNVRAMVariable.h
//	author:		tiamo
//	purpose:	apple nvram variable guid
//********************************************************************

#ifndef _APPLE_NVRAM_VARIABLE_H_
#define _APPLE_NVRAM_VARIABLE_H_

#define APPLE_NVRAM_VARIABLE_GUID											{ 0x7c436110, 0xab2a, 0x4bbb, {0xa8, 0x80, 0xfe, 0x41, 0x99, 0x5c, 0x9f, 0x82} }

extern EFI_GUID gAppleNVRAMVariableGuid;

#endif
