//********************************************************************
//	created:	28:8:2012   19:00
//	filename: 	AppleRamDmgDevicePath.h
//	author:		tiamo
//	purpose:	apple ram dmg device path
//********************************************************************

#ifndef _APPLE_RAM_DMG_DEVICE_PATH_H_
#define _APPLE_RAM_DMG_DEVICE_PATH_H_

#define APPLE_RAM_DMG_DEVICE_PATH_GUID										{ 0x040b07e8, 0x0b9c, 0x427e, {0xb0, 0xd4, 0xa4, 0x66, 0xe6, 0xe5, 0x7a, 0x62} }

extern EFI_GUID gAppleRamDmgDevicePathGuid;

#endif
