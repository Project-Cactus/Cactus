//********************************************************************
//	created:	26:8:2012   17:00
//	filename: 	AppleFirmwareFileName.h
//	author:		tiamo
//	purpose:	apple firmware file name
//********************************************************************

#ifndef _APPLE_FIRMWARE_FILE_NAME_H_
#define _APPLE_FIRMWARE_FILE_NAME_H_

#define APPLE_PASSWORD_UI_EFI_FILE_NAME_GUID								{ 0x9eba2d25, 0xbbe3, 0x4ac2, {0xa2, 0xc6, 0xc8, 0x7f, 0x44, 0xa1, 0x27, 0x8c} }

extern EFI_GUID gApplePasswordUIEfiFileNameGuid;

#endif
