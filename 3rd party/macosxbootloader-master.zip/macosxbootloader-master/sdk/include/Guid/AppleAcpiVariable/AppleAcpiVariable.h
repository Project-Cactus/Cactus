//********************************************************************
//	created:	27:8:2012   21:30
//	filename: 	AppleAcpiVariable.h
//	author:		tiamo
//	purpose:	apple acpi variable
//********************************************************************

#ifndef _APPLE_ACPI_VARIABLE_H_
#define _APPLE_ACPI_VARIABLE_H_

#define APPLE_ACPI_VARIABLE_GUID											{ 0xaf9ffd67, 0xec10, 0x488a, {0x9d, 0xfc, 0x6c, 0xbf, 0x5e, 0xe2, 0x2c, 0x2e} }

extern EFI_GUID gAppleAcpiVariableGuid;

#endif
