//********************************************************************
//	created:	30:9:2012   1:50
//	filename: 	AppleFileVaultVariable.h
//	author:		tiamo
//	purpose:	apple file vault variable
//********************************************************************

#ifndef _APPLE_FILE_VAULT_VARIABLE_H_
#define _APPLE_FILE_VAULT_VARIABLE_H_

#define APPLE_FILE_VAULT_VARIABLE_GUID										{ 0x8d63d4fe, 0xbd3c, 0x4aad, {0x88, 0x1d, 0x86, 0xfd, 0x97, 0x4b, 0xc1, 0xdf} }

extern EFI_GUID gAppleFileVaultVariableGuid;

#endif
