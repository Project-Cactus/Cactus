//********************************************************************
//	created:	21:8:2012   21:41
//	filename: 	AppleFirmwareVariable.h
//	author:		tiamo
//	purpose:	apple firmware variable
//********************************************************************

#ifndef _APPLE_FIRMWARE_VARIABLE_H_
#define _APPLE_FIRMWARE_VARIABLE_H_

#define APPLE_FIRMWARE_VARIABLE_GUID { 0x4d1ede05, 0x38c7, 0x4a6a, {0x9c, 0xc6, 0x4b, 0xcc, 0xa8, 0xb3, 0x8c, 0x14} }

extern EFI_GUID gAppleFirmwareVariableGuid;

#endif
