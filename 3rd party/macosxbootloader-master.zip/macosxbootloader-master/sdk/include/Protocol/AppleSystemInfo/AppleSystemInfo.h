//********************************************************************
//	created:	21:8:2012   22:18
//	filename: 	AppleSystemInfo.h
//	author:		tiamo
//	purpose:	apple system info
//********************************************************************

#ifndef _APPLE_SYSTEM_INFO_H_
#define _APPLE_SYSTEM_INFO_H_

#define APPLE_SYSTEM_INFO_PRODUCER_NAME_GUID								{ 0x64517cc8, 0x6561, 0x4051, {0xb0, 0x3c, 0x59, 0x64, 0xb6, 0x0f, 0x4c, 0x7a} }

typedef struct _APPLE_SYSTEM_INFO_DATA_RECORD
{
	UINT32																	Unknown[4];
	UINT32																	NameLength;
	UINT32																	ValueLength;
}APPLE_SYSTEM_INFO_DATA_RECORD;

extern EFI_GUID gAppleSystemInfoProducerNameGuid;

#endif
