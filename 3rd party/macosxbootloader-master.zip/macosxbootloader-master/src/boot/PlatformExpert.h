//********************************************************************
//	created:	7:11:2009   12:49
//	filename: 	PlatformExpert.h
//	author:		tiamo
//	purpose:	platform expert
//********************************************************************

#pragma once

//
// init platform node
//
EFI_STATUS PeInitialize();

//
// get model name
//
CHAR8 CONST* PeGetModelName();

//
// setup device tree
//
EFI_STATUS PeSetupDeviceTree();