//********************************************************************
//	created:	11:11:2009   21:31
//	filename: 	LoadDrivers.h
//	author:		tiamo
//	purpose:	load drivers
//********************************************************************

#pragma once

//
// load drivers
//
EFI_STATUS LdrLoadDrivers();
