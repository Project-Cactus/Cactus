//********************************************************************
//	created:	11:11:2009   0:16
//	filename: 	Crc32.h
//	author:		tiamo
//	purpose:	crc32
//********************************************************************

#pragma once

//
// calc crc32
//
UINT32 BlCrc32(UINT32 crcValue, VOID CONST* inputBuffer, UINTN bufferLength);