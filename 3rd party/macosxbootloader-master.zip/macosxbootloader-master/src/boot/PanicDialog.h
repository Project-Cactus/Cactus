//********************************************************************
//	created:	12:9:2012   23:09
//	filename: 	PanicDialog.h
//	author:		tiamo
//	purpose:	panic dialog
//********************************************************************

#pragma once

//
// show panic dialog
//
VOID BlShowPanicDialog(CHAR8** kernelCommandLine);
