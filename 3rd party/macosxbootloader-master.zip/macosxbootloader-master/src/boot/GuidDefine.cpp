//********************************************************************
//	created:	4:8:2012   13:41
//	filename: 	GuidDefine.cpp
//	author:		tiamo
//	purpose:	guid define
//********************************************************************

#include "StdAfx.h"
#include "GuidDefine.h"

EFI_GUID EfiDataHubProtocolGuid												= EFI_DATA_HUB_PROTOCOL_GUID;
EFI_GUID EfiAcpi20TableGuid													= EFI_ACPI_20_TABLE_GUID;
EFI_GUID EfiAcpiTableGuid													= EFI_ACPI_TABLE_GUID;
EFI_GUID EfiLoadedImageProtocolGuid											= EFI_LOADED_IMAGE_PROTOCOL_GUID;
EFI_GUID EfiPciIoProtocolGuid												= EFI_PCI_IO_PROTOCOL_GUID;
EFI_GUID EfiSmbiosTableGuid													= EFI_SMBIOS_TABLE_GUID;
EFI_GUID EfiConsoleControlProtocolGuid										= EFI_CONSOLE_CONTROL_PROTOCOL_GUID;
EFI_GUID EfiSimpleFileSystemProtocolGuid									= EFI_SIMPLE_FILE_SYSTEM_PROTOCOL_GUID;
EFI_GUID EfiDevicePathProtocolGuid											= EFI_DEVICE_PATH_PROTOCOL_GUID;
EFI_GUID EfiBlockIoProtocolGuid												= EFI_BLOCK_IO_PROTOCOL_GUID;
EFI_GUID EfiDiskIoProtocolGuid												= EFI_DISK_IO_PROTOCOL_GUID;
EFI_GUID EfiGraphicsOutputProtocolGuid										= EFI_GRAPHICS_OUTPUT_PROTOCOL_GUID;
EFI_GUID EfiUgaDrawProtocolGuid												= EFI_UGA_DRAW_PROTOCOL_GUID;
EFI_GUID EfiFileInfoGuid													= EFI_FILE_INFO_ID;
EFI_GUID EfiLoadFileProtocolGuid											= LOAD_FILE_PROTOCOL_GUID;
EFI_GUID EfiFirmwareVolumeProtocolGuid										= EFI_FIRMWARE_VOLUME_PROTOCOL_GUID;
EFI_GUID EfiFirmwareVolumeDispatchProtocolGuid								= EFI_FIRMWARE_VOLUME_DISPATCH_PROTOCOL_GUID;
EFI_GUID EfiDevicePathMessagingSASGuid										= DEVICE_PATH_MESSAGING_SAS;
EFI_GUID EfiSimplePointerProtocolGuid										= EFI_SIMPLE_POINTER_PROTOCOL_GUID;
EFI_GUID AppleKeyStateProtocolGuid											= APPLE_KEY_STATE_PROTOCOL_GUID;
EFI_GUID AppleNVRAMVariableGuid												= APPLE_NVRAM_VARIABLE_GUID;
EFI_GUID AppleFirmwareVariableGuid											= APPLE_FIRMWARE_VARIABLE_GUID;
EFI_GUID AppleAcpiVariableGuid												= APPLE_ACPI_VARIABLE_GUID;
EFI_GUID AppleSystemInfoProducerNameGuid									= APPLE_SYSTEM_INFO_PRODUCER_NAME_GUID;
EFI_GUID AppleDevicePropertyProtocolGuid									= APPLE_DEVICE_PROPERTY_PROTOCOL_GUID;
EFI_GUID AppleNetBootProtocolGuid											= APPLE_NET_BOOT_PROTOCOL_GUID;
EFI_GUID ApplePasswordUIEfiFileNameGuid										= APPLE_PASSWORD_UI_EFI_FILE_NAME_GUID;
EFI_GUID AppleFirmwarePasswordProtocolGuid									= APPLE_FIRMWARE_PASSWORD_PROTOCOL_GUID;
EFI_GUID AppleDeviceControlProtocolGuid										= APPLE_DEVICE_CONTROL_PROTOCOL_GUID;
EFI_GUID AppleGraphConfigProtocolGuid										= APPLE_GRAPH_CONFIG_PROTOCOL_GUID;
EFI_GUID AppleGraphInfoProtocolGuid											= APPLE_GRAPH_INFO_PROTOCOL_GUID;
EFI_GUID AppleRamDmgDevicePathGuid											= APPLE_RAM_DMG_DEVICE_PATH_GUID;
EFI_GUID AppleImageCodecProtocolGuid										= APPLE_IMAGE_CODEC_PROTOCOL_GUID;
EFI_GUID AppleDiskIoProtocolGuid											= APPLE_DISK_IO_PROTOCOL_GUID;
EFI_GUID AppleSMCProtocolGuid												= APPLE_SMC_PROTOCOL_GUID;
EFI_GUID AppleFileVaultVariableGuid											= APPLE_FILE_VAULT_VARIABLE_GUID;

EFI_SYSTEM_TABLE* EfiSystemTable											= nullptr;
EFI_BOOT_SERVICES* EfiBootServices											= nullptr;
EFI_RUNTIME_SERVICES* EfiRuntimeServices									= nullptr;
EFI_HANDLE EfiImageHandle													= nullptr;